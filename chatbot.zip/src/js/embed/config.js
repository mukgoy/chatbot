//embed/config.js
var staticHost = "http://www.chatbot.com/";
var apiHost = "https://api.hrbot.co/walkinapp/api/";
var postmanOptions = {
    origin: 'http://www.chatbot.com',
	path: "/chatbot.html",
};
