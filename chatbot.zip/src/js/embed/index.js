//embed/index.js
addStyleSheet(staticHost + "css/embed.css");
