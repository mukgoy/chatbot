//chatbot/channel.js
var channel = (function () {
  let options = {
    loadIframe: false
  };
  return Postman(options);
})();


